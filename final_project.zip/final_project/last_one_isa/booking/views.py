from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib import messages
from django.http import HttpResponse
from .models import Booking, Field

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Log in the user immediately after registering
            messages.success(request, 'You are now registered and logged in.')
            return redirect('home')  # Redirect to the booking page
        else:
            messages.error(request, 'Invalid registration details.')
    else:
        form = UserCreationForm()
    return render(request, 'booking/register.html', {'form': form})

@login_required
def book_field(request):
    if request.method == 'POST':
        user = request.user
        field_id = request.POST.get('field_id')
        start_time = request.POST.get('start_time')
        end_time = request.POST.get('end_time')
        date = request.POST.get('date')

        # Validate that the field exists
        try:
            field = Field.objects.get(id=field_id)
        except Field.DoesNotExist:
            messages.error(request, "The requested field does not exist.")
            return redirect('book_field')  # Redirect back to the booking form

        # Create and save the new booking
        booking = Booking(user=user, field=field, start_time=start_time, end_time=end_time, date=date)
        booking.save()
        messages.success(request, 'Your booking has been successful!')
        return redirect('booking_success')  # Adjust this URL to your success page
    else:
        fields = Field.objects.all()
        return render(request, 'booking/booking.html', {'fields': fields})

def booking_success(request):
    return render(request, 'booking/booking_success.html')

def home(request):
    return render(request, 'booking/home.html')

def stadiums(request):
    return render(request, 'booking/stadiums.html')
