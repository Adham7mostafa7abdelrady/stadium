# from django.db import models
# from django.contrib.auth import get_user_model

# # Get the default User model
# User = get_user_model()

# class Field(models.Model):
#     name = models.CharField(max_length=40)
#     size = models.DecimalField(max_digits=6, decimal_places=2)
#     work_time = models.CharField(max_length=40)
#     status = models.BooleanField(default=True)
#     city = models.CharField(max_length=40)
#     street = models.CharField(max_length=50)
#     price_per_hour = models.DecimalField(max_digits=6, decimal_places=2)

#     def __str__(self):
#         return self.name

# class Booking(models.Model):
#     user = models.ForeignKey(User, on_delete=models.CASCADE)
#     field = models.ForeignKey(Field, on_delete=models.CASCADE, related_name='bookings')
#     start_time = models.TimeField()
#     end_time = models.TimeField()
#     date = models.DateField()

#     def __str__(self):
#         return f"{self.user.username} booking at {self.field.name} on {self.date}"

from django.db import models
from django.contrib.auth import get_user_model

# Get the default User model
User = get_user_model()

class Field(models.Model):
    name = models.CharField(max_length=40)
    size = models.DecimalField(max_digits=6, decimal_places=2)
    work_time = models.CharField(max_length=40)
    status = models.BooleanField(default=True)
    city = models.CharField(max_length=40)
    street = models.CharField(max_length=50)
    price_per_hour = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        return self.name

class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    field = models.ForeignKey(Field, on_delete=models.CASCADE, related_name='bookings')
    user_name = models.CharField(max_length=150, blank=True)  # New field for user's username
    field_name = models.CharField(max_length=40, blank=True)  # New field for field's name
    start_time = models.TimeField()
    end_time = models.TimeField()
    date = models.DateField()

    def save(self, *args, **kwargs):
        # Automatically update the username and field name before saving
        self.user_name = self.user.username
        self.field_name = self.field.name
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user.username} booking at {self.field.name} on {self.date}"
