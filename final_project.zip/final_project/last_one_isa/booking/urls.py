from django.urls import path
from .views import book_field, booking_success, stadiums, home, register
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('home/', home, name='home'),
    path('stadiums/', stadiums, name='stadiums'),
    path('booking/', book_field, name='book_field'),
    path('booking-success/', booking_success, name='booking_success'),
    path('login/', auth_views.LoginView.as_view(template_name='booking/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='home'), name='logout'),  # Redirect to home after logout
    path('register/', register, name='register'),
]
    

