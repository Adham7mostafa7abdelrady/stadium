from django.contrib import admin
from .models import Field, Booking

# Register your models here.

admin.site.register(Field)
admin.site.register(Booking)